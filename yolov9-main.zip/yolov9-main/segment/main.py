# -*- coding: utf-8 -*-

import subprocess
import sys
import os

def run_prediction(weights, source, imgsz, conf_thres, device, name, view_img=False):
    # 获取当前Python解释器路径
    python_executable = sys.executable

    # 构建命令
    command = [
        python_executable, 'predict.py',  # 调用predict.py脚本
        '--weights', weights,
        '--source', source,
        '--imgsz', str(imgsz),
        '--conf-thres', str(conf_thres),
        '--device', device,
        '--name', name,
    ]

    if view_img:
        command.append('--view-img')

    # 运行命令
    result = subprocess.run(command, capture_output=True, text=True)

    if result.returncode == 0:
        print("Prediction successful")
        print(result.stdout)
    else:
        print("Prediction failed")
        print(result.stderr)


if __name__ == "__main__":
    # 设置参数
    weights = 'I:/拼接/计数论文数据/多光谱训练数据/green/exp5/weights/best.pt'  # 模型权重路径
    source = 'segment/2.tiff'  # 输入图像路径
    imgsz = 640  # 推理图像尺寸
    conf_thres = 0.25  # 置信度阈值
    device = 0  # CUDA设备
    name = 'cpu'
    view_img = False  # 是否显示结果图像

    # 调用预测函数
    run_prediction(weights, source, imgsz, conf_thres, device, name, view_img)
