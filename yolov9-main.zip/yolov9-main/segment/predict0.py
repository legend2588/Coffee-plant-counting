# -*- coding: utf-8 -*-
import argparse
import os
import platform
import sys
import torch
from pathlib import Path

# 获取当前文件路径
FILE = Path(__file__).resolve()
# 获取YOLO根目录
ROOT = FILE.parents[1]
# 将根目录添加到系统路径中
if str(ROOT) not in sys.path:
    sys.path.append(str(ROOT))
# 将根目录路径转换为相对路径
ROOT = Path(os.path.relpath(ROOT, Path.cwd()))

# 导入相关模块和函数
from models.common import DetectMultiBackend
from utils.dataloaders import IMG_FORMATS, VID_FORMATS, LoadImages, LoadScreenshots, LoadStreams
from utils.general import (LOGGER, Profile, check_file, check_img_size, check_imshow, check_requirements, colorstr, cv2,
                           increment_path, non_max_suppression, print_args, scale_boxes, scale_segments,
                           strip_optimizer, xyxy2xywh)
from utils.plots import Annotator, colors, save_one_box
from utils.segment.general import masks2segments, process_mask
from utils.torch_utils import select_device, smart_inference_mode


@smart_inference_mode()
def run(
    weights=ROOT / 'yolo-seg.pt',  # 模型权重文件路径
    source=ROOT / 'data/合并框图片',  # 输入数据源，可以是文件/目录/URL/屏幕截图/摄像头
    data=ROOT / 'data/coco.yaml',  # 数据集配置文件路径
    imgsz=(640, 640),  # 推理图像尺寸（高度, 宽度）
    conf_thres=0.25,  # 置信度阈值
    iou_thres=0.45,  # 非极大值抑制(NMS)的IOU阈值
    max_det=1000,  # 每张图像的最大检测数量
    device='',  # 使用的设备，例如 0 或 0,1,2,3 或 cpu
    view_img=False,  # 是否显示结果图像
    save_txt=False,  # 是否保存结果到*.txt文件
    save_conf=False,  # 是否在*.txt标签中保存置信度
    save_crop=False,  # 是否保存裁剪的预测框
    nosave=False,  # 是否保存图像/视频
    classes=None,  # 按类过滤，例如 --class 0 或 --class 0 2 3
    agnostic_nms=False,  # 类别无关的NMS
    augment=False,  # 是否使用增强推理
    visualize=False,  # 是否可视化特征
    update=False,  # 是否更新所有模型
    project=ROOT / 'runs/predict-seg',  # 保存结果的项目路径
    name='exp',  # 保存结果的项目名称
    exist_ok=False,  # 是否允许现有项目/名称
    line_thickness=3,  # 边框厚度（像素）
    hide_labels=False,  # 是否隐藏标签
    hide_conf=False,  # 是否隐藏置信度
    half=False,  # 是否使用FP16半精度推理
    dnn=False,  # 是否使用OpenCV DNN进行ONNX推理
    vid_stride=1,  # 视频帧率步长
    retina_masks=False,  # 是否以原生分辨率绘制掩码
):
    source = str(source)
    save_img = not nosave and not source.endswith('.txt')  # 判断是否保存推理图像
    is_file = Path(source).suffix[1:] in (IMG_FORMATS + VID_FORMATS)  # 判断输入源是否为文件
    is_url = source.lower().startswith(('rtsp://', 'rtmp://', 'http://', 'https://'))  # 判断输入源是否为URL
    webcam = source.isnumeric() or source.endswith('.txt') or (is_url and not is_file)  # 判断输入源是否为摄像头
    screenshot = source.lower().startswith('screen')  # 判断输入源是否为屏幕截图
    if is_url and is_file:
        source = check_file(source)  # 如果是URL且是文件，则下载

    # 创建保存目录
    save_dir = increment_path(Path(project) / name, exist_ok=exist_ok)
    (save_dir / 'labels' if save_txt else save_dir).mkdir(parents=True, exist_ok=True)

    # 加载模型
    device = select_device(device)
    model = DetectMultiBackend(weights, device=device, dnn=dnn, data=data, fp16=half)
    stride, names, pt = model.stride, model.names, model.pt
    imgsz = check_img_size(imgsz, s=stride)  # 检查图像尺寸

    # 数据加载器
    bs = 1  # 批量大小
    if webcam:
        view_img = check_imshow(warn=True)
        dataset = LoadStreams(source, img_size=imgsz, stride=stride, auto=pt, vid_stride=vid_stride)
        bs = len(dataset)
    elif screenshot:
        dataset = LoadScreenshots(source, img_size=imgsz, stride=stride, auto=pt)
    else:
        dataset = LoadImages(source, img_size=imgsz, stride=stride, auto=pt, vid_stride=vid_stride)
    vid_path, vid_writer = [None] * bs, [None] * bs

    # 运行推理
    model.warmup(imgsz=(1 if pt else bs, 3, *imgsz))  # 模型预热
    seen, windows, dt = 0, [], (Profile(), Profile(), Profile())
    for path, im, im0s, vid_cap, s in dataset:
        with dt[0]:
            im = torch.from_numpy(im).to(model.device)
            im = im.half() if model.fp16 else im.float()  # uint8 转换为 fp16/32
            im /= 255  # 归一化 0 - 255 到 0.0 - 1.0
            if len(im.shape) == 3:
                im = im[None]  # 扩展为批量维度

        # 推理
        with dt[1]:
            visualize = increment_path(save_dir / Path(path).stem, mkdir=True) if visualize else False
            pred, proto = model(im, augment=augment, visualize=visualize)[:2]

        # 非极大值抑制(NMS)
        with dt[2]:
            pred = non_max_suppression(pred, conf_thres, iou_thres, classes, agnostic_nms, max_det=max_det, nm=32)

        # 处理预测结果
        for i, det in enumerate(pred):  # 对每张图像进行处理
            seen += 1
            if webcam:  # 批量大小 >= 1
                p, im0, frame = path[i], im0s[i].copy(), dataset.count
                s += f'{i}: '
            else:
                p, im0, frame = path, im0s.copy(), getattr(dataset, 'frame', 0)

            p = Path(p)  # 转换为Path对象
            save_path = str(save_dir / p.name)  # 保存路径
            txt_path = str(save_dir / 'labels' / p.stem) + ('' if dataset.mode == 'image' else f'_{frame}')  # txt文件路径
            s += '%gx%g ' % im.shape[2:]  # 打印字符串
            imc = im0.copy() if save_crop else im0  # 用于保存裁剪的预测框
            annotator = Annotator(im0, line_width=line_thickness, example=str(names))
            if len(det):
                test = proto[2] if len(proto) == 3 else proto
                masks = process_mask(test, det[:, 6:], det[:, :4], im.shape[2:], upsample=True)  # HWC
                det[:, :4] = scale_boxes(im.shape[2:], det[:, :4], im0.shape).round()  # 将边框缩放到im0大小

                # 处理分割掩码
                if save_txt:
                    segments = reversed(masks2segments(masks))
                    segments = [scale_segments(im.shape[2:], x, im0.shape, normalize=True) for x in segments]

                # 打印结果
                for c in det[:, 5].unique():
                    n = (det[:, 5] == c).sum()  # 每个类别的检测数量
                    s += f"{n} {names[int(c)]}{'s' * (n > 1)}, "  # 添加到字符串

                # 绘制掩码
                annotator.masks(masks,
                                colors=[colors(x, True) for x in det[:, 5]],
                                im_gpu=None if retina_masks else im[i])



                # 写入结果
                for j, (*xyxy, conf, cls) in enumerate(reversed(det[:, :6])):
                    if save_txt:  # 写入文件
                        segj = segments[j].reshape(-1)  # (n,2) 转换为 (n*2)
                        line = (cls, *segj, conf) if save_conf else (cls, *segj)  # 标签格式
                        with open(f'{txt_path}.txt', 'a') as f:
                            f.write(('%g ' * len(line)).rstrip() % line + '\n')

                    if save_img or save_crop or view_img:  # 预测框和标签
                        c = int(cls)  # 类别
                        label = None if hide_labels else (names[c] if hide_conf else f'{names[c]} {conf:.2f}')
                        color = colors(c, True)
                        annotator.box_label(xyxy, label, color=color)

                        if save_crop:
                            save_one_box(xyxy, imc, file=save_dir / 'crops' / names[c] / f'{p.stem}.jpg', BGR=True)

            # 打印时间
            LOGGER.info(f'{s}Done. ({t3 - t2:.3f}s)')

            # 保存结果
            if save_img:
                if dataset.mode == 'image':
                    cv2.imwrite(save_path, im0)
                else:  # 视频文件
                    if vid_path[i] != save_path:  # 初始化新的视频文件
                        vid_path[i] = save_path
                        if isinstance(vid_writer[i], cv2.VideoWriter):
                            vid_writer[i].release()  # 释放上一视频写入器

                        fourcc = 'mp4v'  # 输出视频格式
                        fps = vid_cap.get(cv2.CAP_PROP_FPS)
                        w = int(vid_cap.get(cv2.CAP_PROP_FRAME_WIDTH))
                        h = int(vid_cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
                        vid_writer[i] = cv2.VideoWriter(save_path, cv2.VideoWriter_fourcc(*fourcc), fps, (w, h))
                    vid_writer[i].write(im0)

            # 显示结果
            if view_img:
                cv2.imshow(str(p), im0)
                cv2.waitKey(1)  # 1 ms延迟

    # 打印时间（总计、预处理、推理、NMS）
    t = tuple(x.t / seen * 1E3 for x in dt)
    LOGGER.info(f'Speed: %.1fms pre-process, %.1fms inference, %.1fms NMS per image at shape {(1, 3, *imgsz)}' % t)
    if save_txt or save_img:
        s = f"\n{len(list(save_dir.glob('labels/*.txt')))} labels saved to {save_dir / 'labels'}" if save_txt else ''
        LOGGER.info(f"Results saved to {colorstr('bold', save_dir)}{s}")
    if update:
        strip_optimizer(weights)  # 更新模型（去除优化器）

def parse_opt():
    parser = argparse.ArgumentParser()
    parser.add_argument('--weights', nargs='+', type=str, default=ROOT / 'yolo-seg.pt', help='model path(s)')
    parser.add_argument('--source', type=str, default=ROOT / 'data/合并框图片', help='file/dir/URL/glob/screen/0(webcam)')
    parser.add_argument('--data', type=str, default=ROOT / 'data/coco.yaml', help='(optional) dataset.yaml path')
    parser.add_argument('--imgsz', '--img', '--img-size', nargs='+', type=int, default=[640, 640], help='inference size h,w')
    parser.add_argument('--conf-thres', type=float, default=0.25, help='confidence threshold')
    parser.add_argument('--iou-thres', type=float, default=0.45, help='NMS IoU threshold')
    parser.add_argument('--max-det', type=int, default=1000, help='maximum detections per image')
    parser.add_argument('--device', default='', help='cuda device, i.e. 0 or 0,1,2,3 or cpu')
    parser.add_argument('--view-img', action='store_true', help='show results')
    parser.add_argument('--save-txt', action='store_true', help='save results to *.txt')
    parser.add_argument('--save-conf', action='store_true', help='save confidences in --save-txt labels')
    parser.add_argument('--save-crop', action='store_true', help='save cropped prediction boxes')
    parser.add_argument('--nosave', action='store_true', help='do not save 合并框图片/videos')
    parser.add_argument('--classes', nargs='+', type=int, help='filter by class: --class 0, or --class 0 2 3')
    parser.add_argument('--agnostic-nms', action='store_true', help='class-agnostic NMS')
    parser.add_argument('--augment', action='store_true', help='augmented inference')
    parser.add_argument('--visualize', action='store_true', help='visualize features')
    parser.add_argument('--update', action='store_true', help='update all models')
    parser.add_argument('--project', default=ROOT / 'runs/predict-seg', help='save results to project/name')
    parser.add_argument('--name', default='exp', help='save results to project/name')
    parser.add_argument('--exist-ok', action='store_true', help='existing project/name ok, do not increment')
    parser.add_argument('--line-thickness', default=3, type=int, help='bounding box thickness (pixels)')
    parser.add_argument('--hide-labels', action='store_true', help='hide labels')
    parser.add_argument('--hide-conf', action='store_true', help='hide confidences')
    parser.add_argument('--half', action='store_true', help='use FP16 half-precision inference')
    parser.add_argument('--dnn', action='store_true', help='use OpenCV DNN for ONNX inference')
    parser.add_argument('--vid-stride', type=int, default=1, help='video frame-rate stride')
    parser.add_argument('--retina-masks', action='store_true', help='draw high-resolution segmentation masks')
    opt = parser.parse_args()
    return opt

def main(opt):
    check_requirements(exclude=('tensorboard', 'thop'))
    run(**vars(opt))

if __name__ == "__main__":
    opt = parse_opt()
    main(opt)
